
function showLoginForm() {
    const form = document.getElementById("loginForm");
    form.style.display = form.style.display === "block" ? "none" : "block";
}
